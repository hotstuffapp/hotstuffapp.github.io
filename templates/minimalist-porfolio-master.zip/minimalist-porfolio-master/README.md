# Whitespace Minimalist One-Page Portfolio Template
A responsive portfolio template with minimalist style.

Based on: http://purecss.io
